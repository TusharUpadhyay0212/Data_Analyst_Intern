a = 3.14
b = 2.71828
c = 100
d = 5000
e = 1000000
result = int(e)
result_2 = int(c - e)
result_3 = int(e - a)
print(result)
print(result_2)
print(result_3)

