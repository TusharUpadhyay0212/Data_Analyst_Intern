a = 21
b = 6
c = 3
d = 1

print(a - b / c)
print((a - b) / c)
print(a/b*c+d)
print(a/(b*(c+d)))
